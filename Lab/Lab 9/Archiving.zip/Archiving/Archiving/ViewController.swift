//
//  ViewController.swift
//  Archiving
//
//  Created by Mark Green on 2014-11-09.
//  Copyright (c) 2014 Mark Green. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    @IBOutlet weak var logo: UIImageView!
    @IBOutlet weak var slider: UISlider!
    @IBOutlet weak var toggle: UISegmentedControl!
    
    @IBAction func opacityChanged(sender: UISlider) {
        logo.alpha = CGFloat(slider!.value)
    }
    
    @IBAction func toogleChanged(sender: UISegmentedControl) {
        logo.hidden = (toggle.selectedSegmentIndex == 1)
    }
}

