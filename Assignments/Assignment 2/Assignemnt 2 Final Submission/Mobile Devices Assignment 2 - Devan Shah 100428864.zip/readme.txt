How to run the program 

Open up eclipse and import directory Assignment 2 included in the zip file. 
Please make sure that appcompat_v7 is also available in eclipse.

Please use the following device configuration for best performance and design layout:
    Device: Nexus S (4.0", 480 x 800: hdpi)
    Target: Andriod 4.3 - API Level 18
    CPU/ABI: ARM (armeabi-v7a)
    Keyboard: Option selected.
    Skin: Skin with dynamic hardware controls
    Front Camera: None
    Back Camera: None
    Memory Options: RAW: 343  VM Heap: 32
    Internal Storage: 200 MiB
    
    Rest of the devices options should not matter.

If further details are required please let me know and they can be provided. Thanks