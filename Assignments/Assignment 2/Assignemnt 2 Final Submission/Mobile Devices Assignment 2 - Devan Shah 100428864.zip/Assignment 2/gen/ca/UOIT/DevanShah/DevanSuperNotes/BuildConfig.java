/** Automatically generated file. DO NOT MODIFY */
package ca.UOIT.DevanShah.DevanSuperNotes;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}