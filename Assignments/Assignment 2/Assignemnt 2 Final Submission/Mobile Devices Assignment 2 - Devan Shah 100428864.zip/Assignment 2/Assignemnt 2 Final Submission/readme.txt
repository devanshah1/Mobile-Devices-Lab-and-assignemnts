How to run the program 

Open up eclipse and import directory Assignment 1 included in the zip file. 
The zip file also contains directory appcompat_v7 which has to be in the same directory as the Assignemnt 1.

Please use the same device that was configured for Labs. 

If further details are required please let me know and they can be provided. Thanks